# Offline Sprite Pack Preview 0.1.0-rc1

Free local prototype release candidate, prepared2026-09-21. Developed with AI coding assistance. Not published. Extract the whole folder before opening index.html. Files remain local; JSON download still requires manually copying the original PNG beside it.

The sole application-code change from the accepted prototype is the success sentence: "Pack built. Review each animation, then save JSON." It now fits both one and multiple animations. README test instructions were adjusted only to explain the excluded workspace-specific runner and release evidence.

Evidence stays separate:

- Author prototype:27 Node checks and8 Edge checks; original geometric examples only.
- Independent reviewer: fresh single-animation direct-module conversion,137ms stored duration, mapping/trim and rotated-input rejection passed after implementation inspection. Interactive first use was unavailable; this was not a browser/download or native Godot test.
- Release author: extracted-copy browser verification and actual screenshots are recorded outside this archive in RELEASE-VERIFICATION.md. This remains author verification, not a customer or independent interactive result.

The experimental Godot4.4-targeted loader, direct baseline and demo remain unexecuted. Native timing, trim, exported-game/user-folder loading and production compatibility remain unverified. Other browsers, customer benefit, time savings, demand and payment are unverified. The direct native baseline may suffice for a developer; preview and diagnostics are the proposed contribution.

Original code and supplied geometric sprites retain the original CC0 notice in LICENSE.txt. No third-party artwork or dependencies are bundled. Original accepted artifacts were preserved. Company task results, role records, absolute workspace paths, browser automation dependencies and review contracts are excluded.
