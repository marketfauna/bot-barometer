# Same-input result and buyer-work comparison

Observation2026-09-21. Two original geometric packs, same three frame durations100/200/75ms and two animations; different sheet sizes/layouts. No customer files or Aseprite application was used. Fixtures represent a documented JSON-array subset, not an exporter certification.

## Actually executed

- 27 Node checks passed: exact ordered frame geometry, trim offset and canvas; unequal-duration boundaries; unchanged PNG hashes; conversion from renamed/copied folders; rejection of unsupported/bad metadata; mapping and byte/dimension caps.
- 8 existing headless Edge checks passed: both PNGs decoded; expected blue pixels and trimmed orange pixels/background margins; actual downloaded JSON equaled expected generated files; missing required animation disabled old output and showed a specific error; no browser page errors or HTTP requests.
- Desktop screenshot inspected for layout and content. Detailed named checks and browser version are in evidence JSON. This is builder self-verification, not independent validation.

## Criteria and truthful status

| Criterion | Builder / data outcome | Native baseline / native outcome |
|---|---|---|
| Frame order/geometry/timing |Exact fixture expectations pass, including100ms boundary and300ms loop wrap |Direct mapping supplied; runtime readback not executed |
| Trim origin |Browser pixels prove trim offset2,1 on8×8 canvas with4×6 packed region |Source-based AtlasTexture mapping supplied; engine rendering pending |
| Relocation |Copied to two renamed evidence folders; conversion identical; PNG hashes preserved |No actual user:// or moved-folder engine execution |
| Second pack code edits |Zero; same page handles alternate layout |Inspection indicates zero with supplied direct loader; not a timed/native observation |
| Errors |Bad duration, bounds, rotation, tags, names, slices, scale/dimensions and size limits checked |Normalized loader has explicit checks; direct baseline targets trusted fixture subset; neither runtime tested |
| Customer benefit |Preview/mapping/diagnostics visibly available |No independent creator outcome, saved time, preference or willingness-to-pay measured |

## Work that remains with the buyer

| Step | Direct native baseline | Builder plus normalized loader |
|---|---|---|
| Prepare |PNG plus JSON with game tag names |Same assets; can rename animation tags in UI |
| Integrate once |Add direct loader and shared texture constructor; choose folder and required game animations |Add pack loader; choose folder and required game animations |
| Each pack |Copy PNG+source JSON; test game playback |Select two files, check, map/review, download JSON, copy unchanged PNG; test game playback |
| Find geometry/timing problems |Developer reads metadata or inspects game |Browser preview and structured errors assist before game test |
| Changed layout |Expected data-driven mapping; no code patch |Measured data-driven conversion; no code patch |

The proposed route adds conversion steps. There is **no observed reduction in per-pack setup**. Its plausible advantage is a clearer review/error experience for artists and a supported handoff to creators. The direct loader may be sufficient; this result supports an independent use test rather than a paid promise.

Economics remain the prior hypothetical USD29 toolkit scenario; no new cost, sale, support-volume or time-saving measurement supports changing it. No distribution/publication occurred. A future free useful sample/tutorial remains the sensible first exposure; buyer preparation, review and maintenance remain material costs.

## Small next decision

Have one independent reviewer follow README before inspecting implementation. Use a fresh permitted pack variation with a renamed tag and changed duration/offset; freeze first-run answers and failures. Can they identify the required mapping and recover from one specified incompatible input without author help? Compare the direct baseline's documented work honestly. Existing Godot runtime execution can add native evidence if available; absence is a capability limit, not rejection of this opportunity. No further broad converter development is justified yet.
