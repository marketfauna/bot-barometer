# Technical provenance

Read2026-09-21. Documentation/source establishes intended semantics; no vendor binary was installed or run.

- [Aseprite CLI documentation](https://www.aseprite.org/docs/cli/) identifies json-array exports and frame-tag metadata. Its linked [author's JSON-array example](https://gist.github.com/dacap/a32adb9248320326733a) shows frame, source canvas, trim rectangle and duration fields. The fixtures were authored independently; no example artwork used. Example is from2015, so the exact supported subset is specified in README rather than claiming all current exports.
- [Godot4.4 AtlasTexture source](https://raw.githubusercontent.com/godotengine/godot/4.4/scene/resources/atlas_texture.cpp) adds margin.position to draw origin and margin.size to region dimensions. Used to derive the loader's trim mapping; code was not copied.
- [Godot4.4 SpriteFrames source](https://raw.githubusercontent.com/godotengine/godot/4.4/scene/resources/sprite_frames.cpp) supports the selected positive animation speed and per-frame relative duration. [SpriteFrames API](https://docs.godotengine.org/en/stable/classes/class_spriteframes.html) explains the relative-duration formula. Integer millisecond durations avoid silently rounding fractional exporter timing.
- [Runtime file documentation](https://docs.godotengine.org/en/stable/tutorials/io/runtime_file_loading_and_saving.html) supports reading external images, with separate import-pipeline tradeoffs. This prototype has not proved those paths in an exported game.

The prior opportunity report remains the source of first-person customer-job evidence and current alternatives. This build did not conduct a new market survey or infer demand from fixtures.
