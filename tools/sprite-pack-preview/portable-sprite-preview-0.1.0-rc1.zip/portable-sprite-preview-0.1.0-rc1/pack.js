(function(root){
'use strict';
const LIMIT={json:1048576,png:16777216,dimension:2048,frames:512,refs:2048};
function check(ok,message){if(!ok)throw Error(message);}
function integer(n,min,max){return Number.isInteger(n)&&n>=min&&n<=max;}
function name(n){return typeof n==='string'&&/^[A-Za-z0-9_-]{1,40}$/.test(n);}
function basename(n){return typeof n==='string'&&/^[A-Za-z0-9_-][A-Za-z0-9_.-]{0,99}\.png$/.test(n)&&!n.includes('..');}
function pngInfo(bytes){
 check(bytes.byteLength>=24&&bytes.byteLength<=LIMIT.png,'PNG must be 24 bytes to 16 MiB.');
 const a=new Uint8Array(bytes.buffer||bytes,bytes.byteOffset||0,bytes.byteLength);
 check([137,80,78,71,13,10,26,10].every((v,i)=>a[i]===v)&&String.fromCharCode(...a.slice(12,16))==='IHDR','Select a PNG with an IHDR header.');
 const v=new DataView(a.buffer,a.byteOffset,a.byteLength),width=v.getUint32(16),height=v.getUint32(20);
 check(integer(width,1,LIMIT.dimension)&&integer(height,1,LIMIT.dimension),'PNG dimensions must be 1–2048 pixels.');
 return {width,height};
}
function parse(text){check(new TextEncoder().encode(text).length<=LIMIT.json,'JSON exceeds 1 MiB.');try{return JSON.parse(text);}catch(e){throw Error('Metadata is not valid JSON.');}}
function normalize(d,image,required=[],rename={}){
 check(d&&Array.isArray(d.frames)&&d.frames.length>0&&d.frames.length<=LIMIT.frames,'Use JSON-array with 1–512 frames.');
 const m=d.meta;check(m&&m.size&&Array.isArray(m.frameTags)&&m.frameTags.length>0&&m.frameTags.length<=64,'Export metadata with 1–64 animation tags.');
 check(basename(image.name),'PNG name must be a simple ASCII basename, without paths or double dots.');
 check(m.image===image.name,'PNG filename must match meta.image; keep the original basename.');
 check(!m.related_multi_packs?.length&&!d.textures,'Multipage sheets are unsupported; export one sheet.');
 check(String(m.scale)==='1','Export at scale 1.');
 check(m.size.w===image.width&&m.size.h===image.height,'Metadata size does not match PNG dimensions.');
 check(!m.slices?.length,'Slices/pivots are unsupported; export without slices.');
 const frames=d.frames.map((f,i)=>{
  check(f&&f.rotated===false,`Frame ${i}: rotation is unsupported; disable rotation.`);
  const r=f.frame,s=f.spriteSourceSize,z=f.sourceSize;
  check(r&&s&&z,`Frame ${i}: frame, spriteSourceSize and sourceSize required.`);
  check([r.x,r.y,s.x,s.y].every(n=>integer(n,0,LIMIT.dimension))&&[r.w,r.h,s.w,s.h,z.w,z.h].every(n=>integer(n,1,LIMIT.dimension)),`Frame ${i}: invalid geometry.`);
  check(r.x+r.w<=image.width&&r.y+r.h<=image.height,`Frame ${i}: rectangle is outside PNG bounds.`);
  check(s.w===r.w&&s.h===r.h&&s.x+s.w<=z.w&&s.y+s.h<=z.h,`Frame ${i}: trim geometry does not fit source canvas.`);
  check(typeof f.trimmed==='boolean'&&(f.trimmed||(s.x===0&&s.y===0&&s.w===z.w&&s.h===z.h)),`Frame ${i}: inconsistent trimmed flag.`);
  check(integer(f.duration,1,60000),`Frame ${i}: duration must be an integer from 1–60000 ms.`);
  check(!f.image,`Frame ${i}: separate images unsupported.`);
  return {region:[r.x,r.y,r.w,r.h],offset:[s.x,s.y],canvas:[z.w,z.h],duration_ms:f.duration};
 });
 const seen=new Set();let refs=0;
 const animations=m.frameTags.map(t=>{
  check(t&&name(t.name),'Animation names must use 1–40 letters, numbers, underscore or hyphen.');
  check(t.direction==='forward','Only forward animation tags are supported.');
  check(t.repeat===undefined||t.repeat===0,'Finite tag repeat counts are unsupported; use infinite forward loops.');
  check(integer(t.from,0,frames.length-1)&&integer(t.to,t.from,frames.length-1),'Tag range must refer to exported frame indices.');
  const n=Object.hasOwn(rename,t.name)?rename[t.name]:t.name;
  check(name(n)&&!seen.has(n),'Mapped animation names must be valid and unique.');seen.add(n);
  refs+=t.to-t.from+1;check(refs<=LIMIT.refs,'Animation frame references exceed 2048.');
  return {name:n,frames:Array.from({length:t.to-t.from+1},(_,i)=>t.from+i),loop:true};
 });
 for(const n of required){check(name(n),'Required names must use letters, numbers, underscore or hyphen.');check(seen.has(n),`Missing required animation: ${n}. Map a tag or choose another export.`);}
 return {schema:1,image:image.name,size:[image.width,image.height],frames,animations};
}
function frameAt(pack,animation,milliseconds){
 const ids=pack.animations[animation].frames;const total=ids.reduce((s,i)=>s+pack.frames[i].duration_ms,0);let t=((milliseconds%total)+total)%total;
 for(const i of ids){if(t<pack.frames[i].duration_ms)return i;t-=pack.frames[i].duration_ms;}return ids.at(-1);
}
const api={LIMIT,pngInfo,parse,normalize,frameAt};if(typeof module!=='undefined')module.exports=api;else root.Pack=api;
})(globalThis);
