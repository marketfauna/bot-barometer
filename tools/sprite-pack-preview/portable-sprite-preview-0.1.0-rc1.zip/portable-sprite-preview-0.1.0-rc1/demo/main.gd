extends Node2D
func _ready():
	var args = OS.get_cmdline_user_args()
	if args.size() != 2 or not args[0] in ["pack","baseline"]:
		push_error("Usage: -- pack /absolute/path/pack.json OR -- baseline /absolute/path/source.json")
		get_tree().quit(2)
		return
	var loaded = preload("res://portable_pack.gd").load_pack(args[1]) if args[0] == "pack" else preload("res://direct_baseline.gd").load_source(args[1])
	if loaded.get("error", "") != "":
		push_error(loaded.error)
		get_tree().quit(2)
		return
	var sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = loaded.frames
	sprite.position = Vector2(240,180)
	sprite.scale = Vector2(16,16)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(sprite)
	sprite.play("idle")
	print(JSON.stringify(loaded.schema))
	var label = Label.new()
	label.text = "Idle animation. Press Space for walk/idle. Target Godot 4.4; verify output."
	add_child(label)
	set_meta("sprite",sprite)
func _unhandled_key_input(event):
	if event is InputEventKey and event.pressed and event.keycode == KEY_SPACE:
		var sprite = get_meta("sprite")
		sprite.play("walk" if sprite.animation == "idle" else "idle")
