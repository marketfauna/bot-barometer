extends RefCounted
# Direct Aseprite JSON-array baseline for the same trusted, bounded fixtures.
# No builder needed. No claim of accepting arbitrary unsupported exports.
const Pack = preload("res://portable_pack.gd")
static func load_source(path: String) -> Dictionary:
	var read = Pack.read_json(path)
	if read.has("error"):
		return read
	var d = read.data
	if not d.get("frames") is Array or not d.get("meta") is Dictionary:
		return Pack.fail("Baseline requires Aseprite JSON-array metadata.")
	var fs = []
	for f in d.frames:
		if not f is Dictionary or f.get("rotated") != false or not f.get("frame") is Dictionary or not f.get("spriteSourceSize") is Dictionary or not f.get("sourceSize") is Dictionary:
			return Pack.fail("Baseline requires nonrotated frame geometry.")
		var r = f.frame
		var s = f.spriteSourceSize
		var z = f.sourceSize
		fs.append({"region":[r.get("x"),r.get("y"),r.get("w"),r.get("h")],"offset":[s.get("x"),s.get("y")],"canvas":[z.get("w"),z.get("h")],"duration_ms":f.get("duration")})
	var tags = d.meta.get("frameTags")
	if not tags is Array or not d.meta.get("size") is Dictionary:
		return Pack.fail("Baseline needs tags and sheet size.")
	var animations = []
	for t in tags:
		if not t is Dictionary or t.get("direction") != "forward" or not Pack.number(t.get("from"),0,fs.size()-1) or not Pack.number(t.get("to"),t.get("from"),fs.size()-1):
			return Pack.fail("Baseline requires forward tags within frame bounds.")
		animations.append({"name":t.get("name"),"frames":range(int(t.from),int(t.to)+1),"loop":true})
	return Pack.build({"schema":1,"image":d.meta.get("image"),"size":[d.meta.size.get("w"),d.meta.size.get("h")],"frames":fs,"animations":animations},path.get_base_dir())
