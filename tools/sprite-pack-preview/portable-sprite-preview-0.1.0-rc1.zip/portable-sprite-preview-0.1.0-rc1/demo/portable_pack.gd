extends RefCounted
# Target: Godot 4.4 API. NOT executed in Godot during this prototype task.
static func fail(message: String) -> Dictionary:
	return {"error": message}

static func number(n, low, high) -> bool:
	return (typeof(n) == TYPE_INT or typeof(n) == TYPE_FLOAT) and is_finite(float(n)) and n >= low and n <= high

static func integers(a, count: int, low: int, high: int) -> bool:
	if not a is Array or a.size() != count:
		return false
	for n in a:
		if not number(n, low, high) or float(n) != floor(float(n)):
			return false
	return true

static func simple_name(s, image: bool = false) -> bool:
	if not s is String:
		return false
	var pattern = RegEx.new()
	pattern.compile("^[A-Za-z0-9_-][A-Za-z0-9_.-]{0,99}\\.png$" if image else "^[A-Za-z0-9_-]{1,40}$")
	return pattern.search(s) != null and not s.contains("..")

static func read_json(path: String) -> Dictionary:
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null or f.get_length() > 1048576:
		return fail("Cannot read JSON or it exceeds 1 MiB.")
	var parser = JSON.new()
	if parser.parse(f.get_as_text()) != OK or not parser.data is Dictionary:
		return fail("Invalid JSON object.")
	return {"data": parser.data}

static func load_pack(path: String) -> Dictionary:
	var read = read_json(path)
	if read.has("error"):
		return read
	return build(read.data, path.get_base_dir())

static func build(d: Dictionary, directory: String) -> Dictionary:
	if d.get("schema") != 1 or not simple_name(d.get("image"), true) or not integers(d.get("size"), 2, 1, 2048):
		return fail("Expected schema 1, PNG basename and bounded dimensions.")
	var fs = d.get("frames")
	var animations = d.get("animations")
	if not fs is Array or fs.size() < 1 or fs.size() > 512 or not animations is Array or animations.size() < 1 or animations.size() > 64:
		return fail("Expected 1-512 frames and 1-64 animations.")
	for f in fs:
		if not f is Dictionary or not integers(f.get("region"),4,0,2048) or not integers(f.get("offset"),2,0,2048) or not integers(f.get("canvas"),2,1,2048) or not integers([f.get("duration_ms")],1,1,60000):
			return fail("Invalid frame geometry or duration.")
		var r = f.region
		if r[2] < 1 or r[3] < 1 or r[0]+r[2] > d.size[0] or r[1]+r[3] > d.size[1] or f.offset[0]+r[2] > f.canvas[0] or f.offset[1]+r[3] > f.canvas[1]:
			return fail("Frame rectangle or trim offset is out of bounds.")
	var names = {}
	var references = 0
	for a in animations:
		if not a is Dictionary or not simple_name(a.get("name")) or names.has(a.get("name")) or a.get("loop") != true or not a.get("frames") is Array or a.frames.is_empty():
			return fail("Invalid or duplicate animation; only forward loops supported.")
		names[a.name] = true
		references += a.frames.size()
		if references > 2048:
			return fail("Too many frame references.")
		for i in a.frames:
			if not number(i,0,fs.size()-1) or float(i) != floor(float(i)):
				return fail("Animation references an invalid frame.")
	var file = FileAccess.open(directory.path_join(d.image), FileAccess.READ)
	if file == null or file.get_length() < 24 or file.get_length() > 16777216:
		return fail("Cannot read PNG or file exceeds 16 MiB.")
	var bytes = file.get_buffer(file.get_length())
	if bytes.slice(0,8).hex_encode() != "89504e470d0a1a0a" or bytes.slice(12,16).get_string_from_ascii() != "IHDR":
		return fail("Invalid PNG header.")
	file.seek(16)
	file.big_endian = true
	if file.get_32() != int(d.size[0]) or file.get_32() != int(d.size[1]):
		return fail("PNG header differs from bounded metadata dimensions.")
	var image = Image.new()
	if image.load_png_from_buffer(bytes) != OK:
		return fail("PNG decode failed.")
	var texture = ImageTexture.create_from_image(image)
	var textures = []
	for f in fs:
		var atlas = AtlasTexture.new()
		atlas.atlas = texture
		atlas.region = Rect2(f.region[0],f.region[1],f.region[2],f.region[3])
		atlas.margin = Rect2(f.offset[0],f.offset[1],f.canvas[0]-f.region[2],f.canvas[1]-f.region[3])
		atlas.filter_clip = true
		textures.append(atlas)
	var result = SpriteFrames.new()
	result.clear_all()
	result.remove_animation("default")
	for a in animations:
		result.add_animation(a.name)
		result.set_animation_speed(a.name,1000.0)
		result.set_animation_loop(a.name,true)
		for i in a.frames:
			result.add_frame(a.name,textures[int(i)],float(fs[int(i)].duration_ms))
	return {"frames": result, "error": "", "schema": d}
