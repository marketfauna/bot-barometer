"use strict";
const $=id=>document.getElementById(id);let source=null,info=null,bitmap=null,pack=null,playing=true,start=0,pausedAt=0,generation=0;
const ctx=$('preview').getContext('2d');ctx.imageSmoothingEnabled=false;
function status(s,error=false){$('status').textContent=s;$('status').className=error?'error':'';}
function invalidate(){pack=null;$('save').disabled=$('animation').disabled=$('pause').disabled=true;$('frames').replaceChildren();$('receipt').textContent='';ctx.clearRect(0,0,320,320);}
function fileChanged(){generation++;invalidate();source=null;info=null;$('build').disabled=true;$('mapping').textContent='Check the selected files.';status('Files changed. Check again.');}
$('png').onchange=$('json').onchange=fileChanged;
$('check').onclick=async()=>{const ticket=++generation;invalidate();$('build').disabled=true;source=null;try{
 const png=$('png').files[0],json=$('json').files[0];if(!png||!json)throw Error('Choose both the PNG and JSON files.');
 if(json.size>Pack.LIMIT.json||png.size>Pack.LIMIT.png)throw Error('File limit: JSON 1 MiB; PNG 16 MiB.');
 const dim=Pack.pngInfo(await png.arrayBuffer());const d=Pack.parse(await json.text());const image={...dim,name:png.name};
 const normalized=Pack.normalize(d,image);const img=await createImageBitmap(png);if(ticket!==generation){img.close();return;}
 if(img.width!==dim.width||img.height!==dim.height){img.close();throw Error('Decoded PNG dimensions differ from header.');}
 if(bitmap)bitmap.close();bitmap=img;source=d;info=image;$('mapping').replaceChildren();
 for(const a of normalized.animations){const label=document.createElement('label');label.textContent=a.name+' → ';const input=document.createElement('input');input.value=a.name;input.dataset.source=a.name;input.setAttribute('aria-label','Map '+a.name);input.oninput=()=>{invalidate();status('Mapping changed. Build again.');};label.append(input);$('mapping').append(label);}
 $('build').disabled=false;status(`Checked ${d.frames.length} frames. Map names, then build.`);
 }catch(e){if(ticket===generation)status(e.message,true);}};
$('required').oninput=()=>{invalidate();status('Required names changed. Build again.');};
$('build').onclick=()=>{invalidate();try{
 const rename=Object.create(null);for(const input of $('mapping').querySelectorAll('input'))rename[input.dataset.source]=input.value.trim();
 const required=$('required').value.split(',').map(s=>s.trim()).filter(Boolean);pack=Pack.normalize(source,info,required,rename);
 $('animation').replaceChildren(...pack.animations.map((a,i)=>new Option(a.name,i)));$('animation').disabled=$('save').disabled=$('pause').disabled=false;
 for(const [i,f]of pack.frames.entries()){const row=document.createElement('tr');for(const value of [i,f.region.join(','),f.offset.join(','),f.canvas.join(' × '),f.duration_ms+' ms']){const td=document.createElement('td');td.textContent=value;row.append(td);}$('frames').append(row);}
 $('receipt').textContent=`Schema 1\nImage: ${pack.image}\n${pack.frames.length} frames / ${pack.animations.length} animations\nForward loops · original canvas center\nPNG retained unchanged\nNative Godot test pending`;
 playing=true;start=performance.now();pausedAt=0;$('pause').textContent='Pause';status('Pack built. Review each animation, then save JSON.');draw();
 }catch(e){pack=null;status(e.message,true);}};
function draw(){if(!pack||!bitmap)return;const ai=Number($('animation').value)||0;const time=playing?performance.now()-start:pausedAt;const i=Pack.frameAt(pack,ai,time),f=pack.frames[i];
 ctx.fillStyle='#f3f7fa';ctx.fillRect(0,0,320,320);const scale=Math.min(12,280/Math.max(...f.canvas));const ox=(320-f.canvas[0]*scale)/2,oy=(320-f.canvas[1]*scale)/2;
 ctx.drawImage(bitmap,...f.region,ox+f.offset[0]*scale,oy+f.offset[1]*scale,f.region[2]*scale,f.region[3]*scale);
 ctx.strokeStyle='#2b73ba';ctx.strokeRect(ox,oy,f.canvas[0]*scale,f.canvas[1]*scale);ctx.strokeStyle='#ea4c89';ctx.beginPath();ctx.moveTo(154,160);ctx.lineTo(166,160);ctx.moveTo(160,154);ctx.lineTo(160,166);ctx.stroke();$('frame').textContent=`Frame ${i} · ${f.duration_ms} ms`;}
$('animation').onchange=()=>{start=performance.now();pausedAt=0;draw();};
$('pause').onclick=()=>{if(playing)pausedAt=performance.now()-start;else start=performance.now()-pausedAt;playing=!playing;$('pause').textContent=playing?'Pause':'Play';draw();};
$('save').onclick=()=>{if(!pack)return;const url=URL.createObjectURL(new Blob([JSON.stringify(pack,null,2)+'\n'],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='pack.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
function tick(){if(playing)draw();requestAnimationFrame(tick);}requestAnimationFrame(tick);
