const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),P=require('./pack');
const root=__dirname,expected=JSON.parse(fs.readFileSync(path.join(root,'fixtures/expected.json'))),checks=[];
function test(n,fn){fn();checks.push(n);}
function load(label){const dir=path.join(root,'fixtures',label),bytes=fs.readFileSync(path.join(dir,'sprites.png')),d=P.parse(fs.readFileSync(path.join(dir,'source.json'),'utf8'));return {dir,bytes,d,image:{name:'sprites.png',...P.pngInfo(bytes)}};}
for(const label of ['pack-a','pack-b']){
 const {dir,bytes,d,image}=load(label);const p=P.normalize(d,image,['idle','walk']);
 test(label+' exact geometry/timing/origin',()=>{assert.deepEqual(p.frames.map(f=>f.region),expected[label].regions);assert.deepEqual(p.frames.map(f=>f.offset),expected[label].offsets);assert.deepEqual(p.frames.map(f=>f.canvas),expected[label].canvases);assert.deepEqual(p.frames.map(f=>f.duration_ms),[100,200,75]);});
 test(label+' order and unequal duration boundaries',()=>{assert.deepEqual(p.animations.map(a=>a.frames),[[0,1],[2]]);for(const [ms,i] of [[0,0],[99,0],[100,1],[299,1],[300,0]])assert.equal(P.frameAt(p,0,ms),i);assert.equal(P.frameAt(p,1,75),2);});
 test(label+' source bytes preserved',()=>assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),expected[label].image_sha256));
 fs.writeFileSync(path.join(dir,'pack.json'),JSON.stringify(p,null,2)+'\n');
 test(label+' relocated conversion identical',()=>{const moved=path.join(root,'evidence','renamed-'+label);fs.mkdirSync(moved,{recursive:true});for(const f of ['source.json','sprites.png','pack.json'])fs.copyFileSync(path.join(dir,f),path.join(moved,f));const q=P.normalize(P.parse(fs.readFileSync(path.join(moved,'source.json'),'utf8')),{name:'sprites.png',...P.pngInfo(fs.readFileSync(path.join(moved,'sprites.png')))},['idle','walk']);assert.deepEqual(q,p);});
}
const {d,image}=load('pack-a');
for(const [label,edit,pattern] of [
 ['zero duration',x=>x.frames[0].duration=0,/duration/],['fractional duration',x=>x.frames[0].duration=0.5,/duration/],['scaled export',x=>x.meta.scale='2',/scale 1/],['out of bounds',x=>x.frames[0].frame.x=100,/bounds/],['rotation',x=>x.frames[0].rotated=true,/rotation/],['reverse tag',x=>x.meta.frameTags[0].direction='reverse',/forward/],['multipage',x=>x.meta.related_multi_packs=['x.json'],/Multipage/],['slices',x=>x.meta.slices=[{}],/Slices/],['invalid trim',x=>x.frames[1].spriteSourceSize.x=7,/trim/],['tag range',x=>x.meta.frameTags[0].to=9,/range/],['finite repeat',x=>x.meta.frameTags[0].repeat=2,/repeat/],['metadata dimensions',x=>x.meta.size.w=23,/dimensions/],['hash format',x=>x.frames={},/JSON-array/]])test('reject '+label,()=>{const copy=structuredClone(d);edit(copy);assert.throws(()=>P.normalize(copy,image),pattern);});
test('missing required animation',()=>assert.throws(()=>P.normalize(d,image,['attack']),/Missing required animation: attack/));
test('duplicate mapped names',()=>assert.throws(()=>P.normalize(d,image,[],{idle:'walk'}),/unique/));
test('explicit rename',()=>assert.equal(P.normalize(d,image,['rest'],{idle:'rest'}).animations[0].name,'rest'));
test('path-like image rejected',()=>assert.throws(()=>P.normalize(d,{...image,name:'../sprites.png'}),/basename/));
test('JSON size bound',()=>assert.throws(()=>P.parse(' '.repeat(P.LIMIT.json+1)),/1 MiB/));
test('PNG dimension bound',()=>{const bytes=Buffer.from(load('pack-a').bytes);bytes.writeUInt32BE(99999,16);assert.throws(()=>P.pngInfo(bytes),/2048/);});
fs.mkdirSync(path.join(root,'evidence'),{recursive:true});fs.writeFileSync(path.join(root,'evidence','unit-results.json'),JSON.stringify({passed:checks.length,checks,native_execution:false},null,2));console.log(JSON.stringify({passed:checks.length}));
