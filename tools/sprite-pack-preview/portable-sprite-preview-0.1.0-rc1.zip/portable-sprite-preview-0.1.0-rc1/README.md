# Portable Sprite Pack — offline prototype

Open **index.html** in a browser. No server, account, install or upload is needed. This page has been exercised in existing Edge153.0.4234.48. The Godot4.4 API loader and demo are supplied **unexecuted**; native compatibility is not established.

## First successful pack

1. In the page choose `fixtures/pack-a/sprites.png` and its `source.json`, then **Check files**.
2. Keep the `idle` and `walk` mappings and required names, then **Build & preview**.
3. Review idle (100/200ms frames) and walk (75ms frame). Pause when useful. The outline is the original8×8 canvas; the cross marks its center. The orange trimmed frame must retain empty margins, not jump to the top left.
4. **Save pack.json** into a new folder, then copy the original `sprites.png` beside it. The builder downloads JSON only and cannot overwrite your selected PNG. Keep that image basename.
5. Repeat with `pack-b`, which arranges the same frames differently. Neither application source nor the loader needs a per-pack edit. Keep the two packs in separate folders because both use `sprites.png`.
6. Rename or move the containing folder. Relative image references make the data portable. Browser conversion after relocation was tested; actual Godot user-folder loading remains pending.

For your own export, use JSON **array** metadata with tags. Map exported tag names to the names your game expects. Required names are checked before download. Different names may require mapping; geometry does not require manual editing. This is a narrow converter/preview, not a sprite editor.

## Supported contract

One PNG with simple ASCII basename, dimensions1–2048 each and at most16MiB; metadata at most1MiB;1–512 frames;1–64 forward looping tags and at most2048 referenced frames. Names allow letters, numbers, hyphen and underscore,1–40 characters. Durations are integer milliseconds1–60000. The browser checks the PNG header before decode and then checks decoded dimensions.

Input fields: `frames[]` containing `frame:{x,y,w,h}`, `rotated:false`, boolean `trimmed`, `spriteSourceSize:{x,y,w,h}`, `sourceSize:{w,h}`, `duration`; `meta.image`, `meta.size`, `meta.scale:"1"`, `meta.frameTags:[{name,from,to,direction:"forward"}]`. Each tag range indexes exported frame order. Tags must exist; incorrect exported ranges are rejected. Names can be remapped in the page. Original canvas center is the only supported origin.

Reject rotation, multipage, slices/custom pivots, reverse/ping-pong direction, finite repeats, inconsistent trim geometry and mismatched filenames/dimensions. Export a flat rendered sheet; layer metadata does not produce separately animated layers. This prototype does not support color profiles, animation events, collision shapes, gameplay scripts, absolute image paths or arbitrary engine resources. Looping is always forward/infinite. These bounded checks are not a hostile-file security certification.

Output schema1: relative image basename, sheet size, frames with region/offset/canvas/duration_ms, and animations with name/ordered frame indices/loop=true. The source PNG is unchanged. JSON can be inspected directly; no .tres or executable script is embedded in a pack.

## Godot demo and direct baseline — execution still pending

`demo/portable_pack.gd` builds SpriteFrames from normalized packs. `demo/direct_baseline.gd` maps the same trusted Aseprite subset directly, bypassing the builder; both share texture-construction/validation code. The baseline is deliberately strong: a developer can ship it for known inputs and skip the conversion step. It is a comparison implementation, not an independently verified oracle or general hostile-input importer.

When Godot is already available, open the disposable `demo/project.godot`, or run from this folder (substitute the existing executable/path):

```powershell
& 'C:\path\to\existing\godot.exe' --path '.\demo' -- pack 'C:\absolute\pack-folder\pack.json'
& 'C:\path\to\existing\godot.exe' --path '.\demo' -- baseline 'C:\absolute\source-folder\source.json'
```

Space switches idle/walk. Run both modes against both packs and compare centered geometry, timing and printed schema. Then place a pair under the demo's own user directory and pass `user://packs/a/pack.json` or `user://packs/a/source.json`. Repeat after renaming the pack folder. Do not copy these scripts into a production game before that check. This task found no runtime in PATH or narrow Downloads/Program Files checks; it did not perform an exhaustive disk search or install anything.

Timing implementation: animation speed1000, relative duration equal to milliseconds. Trim mapping: atlas region is the packed rectangle; margin.position is spriteSourceSize.x/y; margin.size is full source width/height minus packed width/height. This follows Godot4.4 source semantics, but actual engine playback/readback is required before a compatibility claim.

## Reproduce local checks

With existing Node:

```powershell
node test.js
```

The portable Node checks write under `evidence/` and refresh prebuilt `pack.json` beside fixtures without changing source PNGs. The workspace-specific browser runner is intentionally excluded from this archive. Author-run browser evidence is included under `evidence/`; it does not establish independent interactive use. This derivative release was also verified after extraction in existing Edge; see RELEASE-NOTES.md for the evidence boundary. Neither test path executes Godot.

Read `COMPARISON.md` for observed outcomes and unresolved value. Original code and geometric fixtures are CC0; see LICENSE.txt. No third-party art or implementation was copied.
