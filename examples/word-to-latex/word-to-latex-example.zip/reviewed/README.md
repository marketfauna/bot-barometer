# Reviewed generic LaTeX packet — synthetic demonstration

This is an invented manuscript, not customer work or a journal submission. The numbers, references and figure are deliberately synthetic. It demonstrates conversion plus review of one small document.

Open `manuscript.pdf` to review the two-page result. Edit `manuscript.tex`; its supporting files are `references.bib` and `synthetic-figure.png`. `fixture-manifest.json` records the known content checks. `packet-manifest.json` records hashes of the delivered files, excluding itself.

Build from this folder using Tectonic 0.17.0:

```text
tectonic --untrusted --keep-logs --keep-intermediates manuscript.tex
```

Tectonic and its TeX support packages are not included. A fresh installation may download dependencies. The tested Windows setup used a project-local `TECTONIC_CACHE_DIR`; the executable can be obtained from the [official release](https://github.com/tectonic-typesetting/tectonic/releases/tag/tectonic%400.17.0). No shell escape is required. Compilation was tested with Tectonic/XeTeX, not with pdfLaTeX, latexmk or an online editor.

The free Pandoc 3.11 conversion retained all five native Word equations, merged-table content, a structured citation, the source text-box note and the selected tracked changes. Review then repaired duplicate caption prefixes, a cached table-reference number and table presentation. The table reference was tested by inserting an earlier table: it correctly renumbered from 1 to 2. All final pages were rendered and inspected, including the table at enlarged scale.

Tracked changes were accepted for this demonstration. The handwritten-style typed citation remains literal; its metadata was not invented. Bibliography style is the generic `plainnat` choice, not an author-approved publication style. The figure uses normal LaTeX float placement.

**Limits:** the Word source was not rendered in Word or LibreOffice, so original visual equivalence has not been verified. The mathematical checks cover these five invented expressions only; the author must validate the meaning of real research. There is no official journal template, publisher acceptance, scientific validation, accessibility certification or proven customer time saving. In particular this is **not a JMLR-final packet**, whose required style and build engine were not tested. Compiler stderr retains a Fontconfig default-configuration warning; the resulting PDF was visually checked and its TeX log has no detected layout, undefined-reference or missing-character warnings.
