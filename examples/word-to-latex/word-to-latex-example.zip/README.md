# Word to LaTeX: a reproducible synthetic example

All manuscript text, numbers, references and the figure are invented. No customer manuscript or actual research is included.

## Tools

Use Pandoc3.11 and Tectonic0.17.0 from their official release pages:
https://github.com/jgm/pandoc/releases/tag/3.11
https://github.com/tectonic-typesetting/tectonic/releases/tag/tectonic%400.17.0

Executables, dependencies and caches are not included. Install/use the official tools using the method appropriate to your operating system. A first Tectonic build may download TeX support packages. No shell escape is required; use its untrusted mode below.

## Reproduce the stronger free conversion

Run these commands in this example folder, with the executables on PATH:

```text
pandoc synthetic-source.docx -f docx+citations -t bibtex -o references.bib
pandoc synthetic-source.docx -f docx+citations --track-changes=accept --natbib --bibliography=references.bib --extract-media configured-media -V geometry:margin=1in -s -o configured.tex
tectonic --untrusted --keep-logs --keep-intermediates configured.tex
```

The first two commands were reconstructed and executed in a separate folder; their bibliography bytes and normalized LaTeX text exactly match the accepted configured baseline. The earlier exact argv was not retained, so this is a newly verified reproduction, not a recovered historical command log. Native Word equations were already preserved. Tracked changes are explicitly accepted. Change that policy for your own document only after deciding how revisions should be handled.

## Inspect the repair

`reviewed/` contains the reviewed two-page PDF and editable source, bibliography, figure and the original review receipts. Compile inside that folder:

```text
tectonic --untrusted --keep-logs --keep-intermediates manuscript.tex
```

`repair_case.py` is an optional Python3 demonstration for this exact fixture. It reads configured.tex and writes a new delivery/ directory; it does not modify the Word original or the included reviewed/ directory. It uses Python's standard library. It preserves the five math displays, rebuilds this known table, removes cached caption prefixes and changes this known cached reference to a live reference. It is not a general manuscript repair program. Read its assertions and replacements before running it. For an arbitrary manuscript, review its actual source and targets instead.

The key mutation test: insert a preceding table in a copy and rebuild. The configured target becomes Table2 while its cross-reference remains1. The reviewed target and reference both become2. Both versions compile successfully. The supplied verification receipt records this result; it is one controlled case, not a general quality score.

## Limits

All raw/configured/reviewed PDF pages were inspected. Original Word/LibreOffice layout was not rendered, so source layout equivalence is unknown. Tectonic uses XeTeX; an actual journal template or pdfLaTeX/latexmk submission was not tested. No accessibility certification, time saving or general conversion accuracy follows. The compiler retained a Fontconfig configuration warning; the reviewed PDF was visually readable and its TeX log had no detected layout/reference/missing-character warnings. The author must review real scientific meaning, equations, figures, tables and citations.

## Reuse and feedback

Marketfauna's case-specific Python code and invented sample content may be reused under the included MIT licence. Third-party tools are not bundled and retain their own licences. Generated TeX includes Pandoc's standard template and third-party package references; those components retain their upstream terms.

Public guide: https://marketfauna.com/examples/word-to-latex/
Feedback: hello@marketfauna.com. Send a reproducible problem or description first; do not send an unpublished manuscript without an agreed handling arrangement.
