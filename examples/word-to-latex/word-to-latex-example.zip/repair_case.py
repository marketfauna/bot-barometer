"""Reviewed one-off repairs for this invented manuscript, not a general converter."""
from datetime import datetime,timezone
import hashlib,json,re,shutil
from pathlib import Path

P=Path(__file__).parent
OUT=P/'delivery';OUT.mkdir(exist_ok=True)
text=(P/'configured.tex').read_text(encoding='utf-8')
before=hashlib.sha256(text.encode()).hexdigest()
start=text.index('\\begin{longtable}')
end=text.index('\\end{longtable}',start)+len('\\end{longtable}')
table=r'''\begin{table}[htbp]
\centering
\caption{Invented method values}\label{TableResults}
\begin{tabularx}{\linewidth}{@{}lXrr@{}}
\toprule
\multicolumn{2}{c}{Method and setting} & \multicolumn{2}{c}{Invented outcomes} \\
\cmidrule(lr){1-2}\cmidrule(lr){3-4}
Method & Condition & Score & Uncertainty \\
\midrule
\multirow{2}{*}{Control} & baseline & 0.125 & $\pm0.003$ \\
 & held out & 0.118 & $\pm0.007$ \\
Variant B & long condition name that must wrap without changing its meaning & 0.139 & $\pm0.004$ \\
\bottomrule
\end{tabularx}
\end{table}'''
text=text[:start]+table+text[end:]
assert text.count(r'\hyperref[TableResults]{1}')==1
text=text.replace(r'\hyperref[TableResults]{1}',r'\ref{TableResults}')
assert text.count(r'\caption{Figure 1 Invented series for media extraction only}')==1
text=text.replace(r'\caption{Figure 1 Invented series for media extraction only}',r'\caption{Invented series for media extraction only}')
text=text.replace(r'\usepackage{longtable,booktabs,array}',r'\usepackage{longtable,booktabs,array,tabularx}')
text=text.replace('configured-media/media/image1.png','synthetic-figure.png')
# Confirm all mathematical displays are untouched by the presentation repair.
get_math=lambda t:re.findall(r'\\\[(.*?)\\\]',t,flags=re.S)
assert get_math(text)==get_math((P/'configured.tex').read_text(encoding='utf-8'))
(OUT/'manuscript.tex').write_text(text,encoding='utf-8')
shutil.copyfile(P/'references.bib',OUT/'references.bib')
shutil.copyfile(P/'configured-media/media/image1.png',OUT/'synthetic-figure.png')
log={'applied_at':datetime.now(timezone.utc).isoformat(),'repair_review_started_at':'2026-09-19T15:34:10Z',
 'baseline_sha256':before,'repaired_sha256':hashlib.sha256(text.encode()).hexdigest(),
 'math_displays_unchanged':len(get_math(text))==5,
 'changes':['Rebuilt the five-row merged table with tabularx and preserved all literal values and grouping',
            'Removed cached Table/Figure caption prefixes because LaTeX already numbers captions',
            'Changed the known table reference from a cached clickable 1 to a live LaTeX reference',
            'Packaged the native Pandoc-exported BibTeX and extracted image beside the source'],
 'not_changes':['No equation repair was necessary on these five native OMML examples',
                'No claim of matching unrendered Word layout',
                'No journal style or pdflatex acceptance test performed',
                'Typed Demonstration 2023 citation remains literal; no bibliography metadata invented']}
(P/'repair-log.json').write_text(json.dumps(log,indent=2)+'\n')
print(json.dumps(log,indent=2))
